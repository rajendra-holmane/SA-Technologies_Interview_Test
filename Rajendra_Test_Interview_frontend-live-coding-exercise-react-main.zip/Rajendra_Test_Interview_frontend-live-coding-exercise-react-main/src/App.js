import React, { Component } from "react";
import { QUESTIONS } from "./questions";

class App extends Component {
  state = {
    currentQuestion: 0,
    yesCount: 0,
    responses: [],
    score: null,
    averageScore: 0,
    totalRuns: 0,
  };

  componentDidMount() {
    const totalRuns = parseInt(localStorage.getItem('totalRuns')) || 0;
    const totalScore = parseFloat(localStorage.getItem('totalScore')) || 0;
    this.setState({
      averageScore: totalRuns > 0 ? totalScore / totalRuns : 0,
      totalRuns: totalRuns,
    });
  }

  handleAnswer = (answer) => {
    const { currentQuestion, yesCount, responses } = this.state;
    const updatedYesCount = answer === 'yes' ? yesCount + 1 : yesCount;
    const updatedResponses = [...responses, answer];

    if (currentQuestion + 1 === Object.keys(QUESTIONS).length) {
      this.calculateScore(updatedYesCount);
    } else {
      this.setState({
        currentQuestion: currentQuestion + 1,
        yesCount: updatedYesCount,
        responses: updatedResponses,
      });
    }
  };

  calculateScore(yesCount) {
    const totalQuestions = Object.keys(QUESTIONS).length;
    const score = (100 * yesCount) / totalQuestions;

    const totalRuns = this.state.totalRuns + 1;
    const totalScore = parseFloat(localStorage.getItem('totalScore')) || 0;
    const newTotalScore = totalScore + score;

    localStorage.setItem('totalRuns', totalRuns);
    localStorage.setItem('totalScore', newTotalScore);

    this.setState({
      score: score,
      averageScore: newTotalScore / totalRuns,
      totalRuns: totalRuns,
      yesCount: 0,
      currentQuestion: 0,
      responses: [],
    });
  }

  render() {
    const { currentQuestion, score, averageScore, totalRuns } = this.state;
    const questionText = QUESTIONS[currentQuestion + 1];

    return (
      <div className="main__wrap">
        <main className="container">
          {currentQuestion < Object.keys(QUESTIONS).length ? (
            <div>
              <p>{questionText}</p>
              <button onClick={() => this.handleAnswer('yes')}>Yes</button>
              <button onClick={() => this.handleAnswer('no')}>No</button>
            </div>
          ) : (
            <div>
              <p>Your score: {score}</p>
              <p>Average score across all runs: {averageScore.toFixed(2)}</p>
              <button onClick={() => this.setState({ currentQuestion: 0, yesCount: 0, responses: [], score: null })}>
                Restart
              </button>
            </div>
          )}
          {totalRuns > 0 && (
            <div>
              <p>Average score across all runs: {averageScore.toFixed(2)}</p>
            </div>
          )}
        </main>
      </div>
    );
  }
}

export default App;
